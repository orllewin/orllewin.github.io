Radio for MacOS v1.0

- This hasn't been tested at all, there's no error handling whatsoever. 
- Launch the app, click a station to play it. There's a shortcut to the stations list in the MacOS menu bar.
- You can make your own station list if you have a little tech know-how.
- You'll need to keep an eye on https://orllewin.github.io/ for updates. 

Good luck.

