:::::::..    :::.   :::::::-.  :::    ...     
;;;;``;;;;   ;;`;;   ;;,   `';,;;; .;;;;;;;.  
 [[[,/[[['  ,[[ '[[, `[[     [[[[[,[[     \[[,
 $$$$$$c   c$$$cc$$$c $$,    $$$$$$$$,     $$$
 888b "88bo,888   888,888_,o8P'888"888,_ _,88P
 MMMM   "W" YMM   ""` MMMMP"`  MMM  "YMMMMMP" 

Radio for MacOS v1.0.2

- This hasn't been tested at all, there's no error handling whatsoever. 
- Launch the app, click a station to play it (not all the default stations operate 24/7). 
- There's a shortcut to the stations list in the MacOS menu bar.
- You can make your own station list if you have a little tech know-how, see: https://orllewin.github.io/radio_projects/
- You'll need to keep an eye on https://orllewin.github.io/ for updates. 

Good luck.